/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pica;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class MinhaJanela extends JFrame {
 
    public MinhaJanela() {
        setTitle("Bem-vindo");
        setSize(1920, 1080);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
 
        setLayout(new BorderLayout());
 
      
        JButton btnFechar = new JButton("Fechar");
        // Adiciona listener para fechar a janela ao clicar
        btnFechar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();  
            }
        });
        add(btnFechar, BorderLayout.CENTER);
 
        setVisible(true);
    }
 
    public static void main(String[] args) {
 
        new MinhaJanela();
    }
}
